#include <VP_Os/elinux/vp_os_ltt.h>

int fd_ltt=-1;
