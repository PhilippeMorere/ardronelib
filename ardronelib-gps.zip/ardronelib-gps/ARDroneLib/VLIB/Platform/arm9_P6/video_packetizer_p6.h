#ifndef _VIDEO_PACKETIZER_P6_H_
#define _VIDEO_PACKETIZER_P6_H_

#include <VLIB/video_packetizer.h>

void video_write_data( video_stream_t* const stream, uint32_t code, int32_t length );

#endif // _VIDEO_PACKETIZER_P5P_H_
