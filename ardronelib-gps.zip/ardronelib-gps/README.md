### Modified ARDroneLib based on official ARDroneSDK 2.0.1

This repo contains the patched version of ARDroneLib 2.0.1 used in [ardrone_autonomy](https://github.com/AutonomyLab/ardrone_autonomy) project.

![Build Status](https://api.travis-ci.org/AutonomyLab/ardronelib.svg?branch=master)
